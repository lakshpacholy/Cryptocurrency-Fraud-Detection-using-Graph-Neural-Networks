
import React, { useEffect, useRef, useState, useCallback } from 'react';
import ForceGraph2D from 'react-force-graph-2d';
import { Maximize, ZoomIn, ZoomOut, Target } from 'lucide-react';
import { GraphResponse, GraphNode } from '../types';

interface GraphViewerProps {
  data: GraphResponse;
  onNodeClick: (node: GraphNode) => void;
}

const GraphViewer: React.FC<GraphViewerProps> = ({ data, onNodeClick }) => {
  const fgRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const [highlightNodes, setHighlightNodes] = useState(new Set());
  const [highlightLinks, setHighlightLinks] = useState(new Set());
  const [hoverNode, setHoverNode] = useState<any>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        setDimensions({
          width: entry.contentRect.width,
          height: entry.contentRect.height,
        });
      }
    });
    resizeObserver.observe(containerRef.current);
    return () => resizeObserver.disconnect();
  }, []);

  const updateHighlight = useCallback((node: any) => {
    setHighlightNodes(new Set());
    setHighlightLinks(new Set());

    if (node) {
      const neighbors = new Set();
      const links = new Set();
      
      data.edges.forEach(link => {
        if (link.source === node.id || link.target === node.id) {
          links.add(link);
          neighbors.add(link.source);
          neighbors.add(link.target);
        }
      });

      setHighlightNodes(neighbors);
      setHighlightLinks(links);
    }
  }, [data]);

  const handleNodeClick = (node: any) => {
    updateHighlight(node);
    onNodeClick(node as GraphNode);
    // Center view on node
    fgRef.current.centerAt(node.x, node.y, 400);
  };

  const handleZoom = (factor: number) => {
    const currentZoom = fgRef.current.zoom();
    fgRef.current.zoom(currentZoom * factor, 400);
  };

  const handleReset = () => {
    fgRef.current.zoomToFit(400, 50);
    setHighlightNodes(new Set());
    setHighlightLinks(new Set());
  };

  // Format data for react-force-graph
  const graphData = {
    nodes: data.nodes.map(n => ({
      ...n,
      color: n.type === 'wallet' ? '#22d3ee' : '#a855f7',
      val: Math.max(10, n.risk / 3)
    })),
    links: data.edges
  };

  useEffect(() => {
    if (fgRef.current) {
      fgRef.current.d3Force('link').distance(150);
      fgRef.current.d3Force('charge').strength(-500);
      fgRef.current.zoomToFit(600, 50);
    }
  }, [data]);

  return (
    <div ref={containerRef} className="w-full h-full bg-[#020617] rounded-3xl border border-slate-800 overflow-hidden relative shadow-2xl group/canvas">
      {/* Legend Overlay */}
      <div className="absolute top-6 left-6 z-10 flex flex-col space-y-2">
        <div className="flex items-center space-x-3 px-4 py-2 bg-slate-900/90 backdrop-blur-xl border border-slate-800 rounded-xl shadow-2xl">
          <div className="w-3 h-3 rounded-full bg-cyan-400 animate-pulse"></div>
          <span className="text-[10px] font-black text-slate-300 tracking-widest uppercase">Wallet</span>
        </div>
        <div className="flex items-center space-x-3 px-4 py-2 bg-slate-900/90 backdrop-blur-xl border border-slate-800 rounded-xl shadow-2xl">
          <div className="w-3 h-3 rounded-full bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.5)]"></div>
          <span className="text-[10px] font-black text-slate-300 tracking-widest uppercase">Tx_Node</span>
        </div>
      </div>

      {/* Control Overlay */}
      <div className="absolute bottom-6 right-6 z-10 flex flex-col space-y-2 opacity-0 group-hover/canvas:opacity-100 transition-opacity">
        <button onClick={() => handleZoom(1.2)} className="p-3 bg-slate-900 border border-slate-800 text-cyan-400 hover:text-white rounded-xl shadow-xl transition-all">
          <ZoomIn size={18} />
        </button>
        <button onClick={() => handleZoom(0.8)} className="p-3 bg-slate-900 border border-slate-800 text-cyan-400 hover:text-white rounded-xl shadow-xl transition-all">
          <ZoomOut size={18} />
        </button>
        <button onClick={handleReset} className="p-3 bg-slate-900 border border-slate-800 text-cyan-400 hover:text-white rounded-xl shadow-xl transition-all">
          <Target size={18} />
        </button>
      </div>
      
      <ForceGraph2D
        ref={fgRef}
        graphData={graphData}
        nodeLabel={(node: any) => `
          <div class="bg-[#050816] border border-cyan-500/30 p-4 rounded-2xl shadow-2xl font-mono min-w-[200px]">
            <div class="flex items-center justify-between mb-2">
              <span class="text-[10px] font-black text-cyan-500 uppercase tracking-widest">${node.type}</span>
              <span class="text-[10px] font-black ${node.risk > 70 ? 'text-red-500' : 'text-green-500'}">${node.risk}% RISK</span>
            </div>
            <div class="text-[11px] text-white font-bold mb-1 truncate">${node.label}</div>
            <div class="text-[9px] text-slate-500 break-all opacity-60">${node.id}</div>
          </div>
        `}
        nodeRelSize={5}
        nodeCanvasObject={(node: any, ctx, globalScale) => {
          const label = node.label;
          const fontSize = 12/globalScale;
          ctx.font = `${fontSize}px JetBrains Mono`;
          const textWidth = ctx.measureText(label).width;
          const bckgDimensions = [textWidth, fontSize].map(n => n + fontSize * 0.2);

          // Draw node circle
          const isHighlighted = highlightNodes.has(node.id) || highlightNodes.size === 0;
          ctx.beginPath();
          ctx.arc(node.x, node.y, node.val / globalScale, 0, 2 * Math.PI, false);
          ctx.fillStyle = node.color;
          ctx.globalAlpha = isHighlighted ? 1 : 0.15;
          ctx.fill();

          // Add glowing border to selected
          if (highlightNodes.has(node.id)) {
            ctx.strokeStyle = '#fff';
            ctx.lineWidth = 2/globalScale;
            ctx.stroke();
          }

          // Draw label
          if (globalScale > 3) {
            ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
            ctx.fillText(label, node.x - textWidth/2, node.y + (node.val/globalScale) + fontSize + 2);
          }
        }}
        linkColor={(link: any) => highlightLinks.has(link) || highlightLinks.size === 0 ? 'rgba(34, 211, 238, 0.2)' : 'rgba(34, 211, 238, 0.02)'}
        linkDirectionalParticles={(link: any) => highlightLinks.has(link) || highlightLinks.size === 0 ? 4 : 0}
        linkDirectionalParticleWidth={1.5}
        linkDirectionalParticleSpeed={0.005}
        linkWidth={(link: any) => highlightLinks.has(link) ? 2 : 1}
        onNodeClick={handleNodeClick}
        backgroundColor="transparent"
        width={dimensions.width}
        height={dimensions.height}
      />
    </div>
  );
};

export default GraphViewer;
