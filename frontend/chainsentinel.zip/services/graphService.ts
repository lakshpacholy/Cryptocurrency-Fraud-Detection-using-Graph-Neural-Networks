
import { GraphResponse } from '../types';

const API_BASE_URL = 'https://api.example.com/graph/transaction';

/**
 * Mocks the backend response for demonstration purposes.
 * In a real scenario, this would be a fetch call to the Spring Boot endpoint.
 */
const mockResponse = (txHash: string): GraphResponse => ({
  transactionHash: txHash,
  riskScore: Math.floor(Math.random() * 100),
  nodes: [
    { id: 'origin_wallet', label: 'Origin Wallet', type: 'wallet', risk: 15 },
    { id: txHash, label: 'Main Tx', type: 'transaction', risk: 45 },
    { id: 'mixer_1', label: 'Tornado Cash Proxy', type: 'wallet', risk: 95 },
    { id: 'intermediary_1', label: 'Escrow Account', type: 'wallet', risk: 30 },
    { id: 'sub_tx_1', label: 'Outbound Tx', type: 'transaction', risk: 70 },
    { id: 'target_wallet', label: 'Target Exchange', type: 'wallet', risk: 10 },
  ],
  edges: [
    { source: 'origin_wallet', target: txHash, label: 'initiated' },
    { source: txHash, target: 'mixer_1', label: 'transfer' },
    { source: txHash, target: 'intermediary_1', label: 'transfer' },
    { source: 'mixer_1', target: 'sub_tx_1', label: 'output' },
    { source: 'sub_tx_1', target: 'target_wallet', label: 'deposit' },
  ]
});

export const fetchTransactionGraph = async (txHash: string): Promise<GraphResponse> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Real implementation:
  // const response = await fetch(`${API_BASE_URL}/${txHash}`);
  // if (!response.ok) throw new Error('Failed to fetch transaction data');
  // return response.json();

  // For now, return mock data
  if (!txHash.startsWith('0x')) {
    throw new Error('Invalid Transaction Hash format. Must start with 0x.');
  }
  
  return mockResponse(txHash);
};
