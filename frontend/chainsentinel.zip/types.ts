
export type NodeType = 'wallet' | 'transaction';

export interface GraphNode {
  id: string;
  label: string;
  type: NodeType;
  risk: number; // 0 - 100
}

export interface GraphEdge {
  source: string;
  target: string;
  label: string;
}

export interface GraphResponse {
  transactionHash: string;
  riskScore: number;
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface RiskThresholds {
  low: number;
  medium: number;
}
